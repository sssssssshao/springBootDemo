package com.itmayiedu.service;

import com.itmayiedu.annotation.ExtService;


public interface OrderService {

	public void addOrder();

}
