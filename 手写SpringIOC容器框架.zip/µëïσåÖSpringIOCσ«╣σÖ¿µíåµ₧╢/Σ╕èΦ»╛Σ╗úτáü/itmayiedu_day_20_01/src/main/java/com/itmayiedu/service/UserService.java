package com.itmayiedu.service;

public interface UserService {

	public void add();

}
