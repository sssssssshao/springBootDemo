package com.itmayiedu.annotation;

public @interface ExtService {

}
