package com.itmayiedu.service;

public interface LogService {

	public void addLog();

}
