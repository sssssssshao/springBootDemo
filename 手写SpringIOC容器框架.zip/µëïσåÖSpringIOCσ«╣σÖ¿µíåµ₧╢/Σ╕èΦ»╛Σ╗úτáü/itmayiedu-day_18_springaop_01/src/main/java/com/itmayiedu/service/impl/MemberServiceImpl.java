package com.itmayiedu.service.impl;

import org.springframework.transaction.annotation.Transactional;

import com.itmayiedu.service.MemberService;

public class MemberServiceImpl implements MemberService {

	public void memberAdd() {
		System.out.println("memberAdd");

	}

}
